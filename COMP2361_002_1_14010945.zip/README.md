Popby
=====
 A basic app made by Tyler Feld
 
 To get the app:
 - Copy this git link (https://github.com/felt1-14/popby-app)
 - Go to build.phonegap.com
 - Log in or register an account
 - Go to build.phonegap.com/apps
 - Hit the "+ new app" button
 - Paste the link into the text box and hit pull from .git repository
 - You now have the app linked to PhoneGap Builder
 - Hit the "Ready to build" button
 - The app will now build
 - On your mobile device use a QR Scanner on the QR code
	(A QR Scanner will certainly be available for free on your app store)
 - You will now be asked to install the app, accept this
 (or shown buttons for iOS, Android and Windows in which case choose your relevant platform)
 - Finished, you have the app!